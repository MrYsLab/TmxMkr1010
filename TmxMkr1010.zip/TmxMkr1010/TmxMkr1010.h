#ifndef _TMXMKR1010_H_
#define _TMXMKR1010_H_

class TmxMkr1010 {

public:
};

#endif //_TMXMKR1010_H_
